
---

##### Links:

- [Support](https://unmanic.app/discord)
- [Issues/Feature Requests](https://github.com/Unmanic/plugin.reorder_audio_streams_by_language/issues)
- [Pull Requests](https://github.com/Unmanic/plugin.reorder_audio_streams_by_language/pulls)

---

##### Documentation:

In the plugin settings, specify a 'Search String'.

The plugin will search the files to find matching audio tracks.

The matching audio tracks will be moved to the 1st audio track.


Examples of search strings:

- 'en'
- 'fr'
- 'de'
